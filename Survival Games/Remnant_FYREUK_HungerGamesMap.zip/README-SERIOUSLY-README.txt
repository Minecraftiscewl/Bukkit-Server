  _____                   _   _  _  __
 |  ___|_   _  _ __  ___ | | | || |/ /
 | |_  | | | || '__|/ _ \| | | || ' / 
 |  _| | |_| || |  |  __/| |_| || . \ 
 |_|    \__, ||_|   \___| \___/ |_|\_\
        |___/                         
----------------------------------------
	     REMNANT
	  (Hunger Games)
----------------------------------------
IMPORTANT:
When playing this map in Multiplayer make
sure that in your server.properties file
the following is correct:

enable-command-block=true

Without this you will not be able to make
full use of the map.

----------------------------------------

Thank you for downloading one of FyreUK's
map downloads for 2013.

Remnant was built for and played at the 
Minecraft Expo UK (Insomnia 49) and was 
used in the Hunger Games challenge at 
the event.

INSTALLATION:
Extract the contents of this zip to your
/.minecraft/ folder and allow overwriting.
This will put the "Remnant" world file in 
your /saves folder and can be found on the 
Single Player menu under the name 'Remnant'. 
It will also put the amazing Dokucraft 
Creative texture pack in your resource packs 
folder - please select this resource pack 
ingame before playing the map.

RECOMMENDED:
The texture pack (Dokucraft Creative) uses
special features such as Connected Textures
found in Optifine or MCPatcher. Please use
a Minecraft client with one of these mods
installed to see the full awesomeness of
Dokucraft on the map.

----------------------------------------
Special Thanks to all FyreUK member who
helped make this map and everyone at
Multiplay who let us build this and used
it in such a big fashion at i49.

Map Timelapse on FyreUK here:
http://www.youtube.com/watch?v=iCylwSw48MQ

Super special thanks to:
WantedRobot and the entire Dokucraft team.
Find out more about the Dokucraft Creative
pack here: http://dokucraft.co.uk/
----------------------------------------
CREDITS:
Map Designed and Created by: Matt [iFirez]
                          & SmallerSmiley
Builders:
Matt [iFirez]
Phil [BruteAlmighty87]
SmallerSmiley
NemesisArc
TheMCfarmer
Runnerracer
Wax469
TheWaaz
ProBeats
ek628
Rae
PokingNinja
Amata
TheBlahBlahBlah
Rajkkor
Killertom63
C_R_E_A_T_O_R
Hyyron
Huntondoom
MrAdamas
Soundblastoff
darcness

Special Thanks to: Wol

Thanks again for downloading and enjoy the map,
<3 Matt